const express = require("express");
const server = express();
const controlador = require('./src/data/controlador.json');
const duelista = require('./src/data/duelista.json');
const iniciador = require('./src/data/iniciador.json');
const sentinela = require('./src/data/sentinela.json');

server.listen(1357, () =>{
    console.log("Conexao sucedida!")
})

server.get('/Valorant/:funcao', (req, res) =>{
    if(req.params.funcao == 'controlador'){
        return res.json(controlador)
    }
    if(req.params.funcao == 'duelista'){
        return res.json(duelista)
    }
    if(req.params.funcao == 'iniciador'){
        return res.json(iniciador)
    }
    if(req.params.funcao == 'sentinela'){
        return res.json(sentinela)
    }
})